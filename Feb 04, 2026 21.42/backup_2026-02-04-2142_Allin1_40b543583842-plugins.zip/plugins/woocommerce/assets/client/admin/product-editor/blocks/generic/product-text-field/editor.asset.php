<?php return array('version' => 'dd669914e336078748ae');
