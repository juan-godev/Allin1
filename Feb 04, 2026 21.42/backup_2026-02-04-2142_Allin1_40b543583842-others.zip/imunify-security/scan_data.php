<?php
if ( ! defined( 'WPINC' ) ) {
	exit;
}
return json_decode( '{"lastScanTimestamp": 1769945289, "nextScanTimestamp": 1770508800.0, "username": "dayromco", "malware": [], "config": {"MALWARE_SCANNING": {"enable_scan_cpanel": true, "default_action": "cleanup"}, "PROACTIVE_DEFENCE": {"blamer": true}}, "license": {"status": true, "expiration": null, "user_limit": 2147483647, "id": "SSpVDDK6RkmcdcOv", "user_count": 308, "message": "", "license_type": "imunify360", "upgrade_url": null, "upgrade_url_360": null, "redirect_url": "https://cln.cloudlinux.com/console/imunify360/servers/SSpVDDK6RkmcdcOv/products/IM_UN/convert"}}', true );