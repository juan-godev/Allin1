<?php
global $fontWeightsArrays;
$fontWeightsArrays = array(
	'100'       => 'Thin 100',
	'100italic' => 'Thin 100 Italic',
	'300'       => 'Light 300',
	'300italic' => 'Light 300 Italic',
	'400'       => 'Normal',
	'400italic' => 'Normal Italic',
	'700'       => 'Bold',
	'700italic' => 'Bold Italic',
	'900'       => 'Ultra Bold',
	'900italic' => 'Ultra Bold Italic',
);
?>