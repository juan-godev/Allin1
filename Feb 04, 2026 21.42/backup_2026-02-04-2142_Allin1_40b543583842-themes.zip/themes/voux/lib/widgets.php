<?php
$theme_name = 'voux';
// Include the twitter widget
include PARENT_DIR.'/lib/widgets/twitter-widget.php';
// Include the flickr widget
include PARENT_DIR.'/lib/widgets/flickr-widget.php';
// Include the recent post with thumbnail widget
include PARENT_DIR.'/lib/widgets/recent-posts-thumb-widget.php';
// Include the social icons widget
include PARENT_DIR.'/lib/widgets/social-icons-widget.php';
// Include the contact widget
include PARENT_DIR.'/lib/widgets/contact-widget.php';

?>